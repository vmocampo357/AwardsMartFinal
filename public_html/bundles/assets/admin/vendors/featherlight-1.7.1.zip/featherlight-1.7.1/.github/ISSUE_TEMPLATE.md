What kind of issue is this? (put 'x' between the square brackets)

 - [ ] Question. This issue tracker is not the place for questions. If you want to ask how to do
       something, or to understand why something isn't working the way you expect it to, use
       http://stackoverflow.com/questions/ask .
       Provide working code, starting from http://jsfiddle.net/JNsu6/15/.
       We monitor the tag `featherlight.js`.

 - [ ] Bug report. If you’ve found a bug, you must provide a minimal example in a CodePen,
       starting from http://jsfiddle.net/JNsu6/15/ .

 - [ ] Feature Request. Make sure there's no good way to do what you want first;
       consider asking on http://stackoverflow.com/questions/ask first.


